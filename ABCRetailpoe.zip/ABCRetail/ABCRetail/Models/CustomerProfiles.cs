﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;

namespace Cloud_Storage.Models
{
    public class CustomerProfiles : ITableEntity
    {
        [Key]
        public int Customer_Id { get; set; }  // Unique identifier for the customer
        public string? Customer_Name { get; set; }  // Name of the customer
        public string? Email { get; set; }  // Email of the customer
        public string? Password { get; set; }  // Password for the customer account

        // ITableEntity implementation
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public ETag ETag { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
    }
}
