﻿using System;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;
using Azure;
using Azure.Data.Tables;

namespace Cloud_Storage.Models
{
    public class Order : ITableEntity
    {
        [Key]
        public int Order_Id { get; set; }

        public string? PartitionKey { get; set; }
        public string? RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }

        // Validation attributes
        [Required(ErrorMessage = "Please select a customer.")]
        public int CustomerID { get; set; } // FK to the Customer who placed the order

        [Required(ErrorMessage = "Please select a product.")]
        public int ProductID { get; set; } // FK to the Product being ordered

        [Required(ErrorMessage = "Please select the date.")]
        public DateTime OrderDate { get; set; }

        [Required(ErrorMessage = "Please enter the shipping address.")]
        public string? ShippingAddress { get; set; }
    }
}
