﻿using Azure;
using Azure.Data.Tables;
using System;
using System.ComponentModel.DataAnnotations;

namespace Cloud_Storage.Models
{
    public class Product : ITableEntity
    {
        [Key]
        public int Product_Id { get; set; }  // Unique identifier for the product
        public string? Product_Name { get; set; }  // Name of the product
        public string? Description { get; set; }  // Description of the product
        public string? ImageUrl { get; set; }  // URL of the product image
        public decimal Price { get; set; }  // Price of the product
        public int StockQuantity { get; set; }  // Quantity in stock

        // ITableEntity implementation
        public string? PartitionKey { get; set; }
        public string? RowKey { get; set; }
        public ETag ETag { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
    }
}
