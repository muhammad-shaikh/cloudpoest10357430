﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using System;
using System.IO;
using System.Threading.Tasks;

namespace Cloud_Storage.Services
{
    public class BlobService
    {
        private readonly BlobServiceClient _blobServiceClient;
        private readonly string _containerName = "productimages"; // Updated container name

        public BlobService(string connectionString, string v)
        {
            _blobServiceClient = new BlobServiceClient(connectionString);
        }

        public async Task<string> UploadAsync(Stream fileStream, string fileName)
        {
            try
            {
                var containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
                await containerClient.CreateIfNotExistsAsync(); // Ensure the container exists

                var blobClient = containerClient.GetBlobClient(fileName);
                await blobClient.UploadAsync(fileStream, true); // Overwrite if blob already exists

                Console.WriteLine($"File '{fileName}' uploaded to container '{_containerName}'.");
                return blobClient.Uri.ToString();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error uploading file: {ex.Message}");
                throw;
            }
        }

        public async Task DeleteBlobAsync(string blobUri)
        {
            try
            {
                Uri uri = new Uri(blobUri);
                string blobName = uri.Segments[^1]; // Extract blob name from URI

                var containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
                var blobClient = containerClient.GetBlobClient(blobName);

                await blobClient.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots);

                Console.WriteLine($"Blob '{blobName}' deleted from container '{_containerName}'.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deleting blob: {ex.Message}");
                throw;
            }
        }
    }
}
