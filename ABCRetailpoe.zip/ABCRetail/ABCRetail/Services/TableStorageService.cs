﻿using Azure;
using Azure.Data.Tables;
using Cloud_Storage.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

public class TableStorageService
{
    private readonly TableClient _customerProfilesTableClient;
    private readonly TableClient _productsTableClient;
    private readonly TableClient _ordersTableClient;

    public TableStorageService(string connectionString)
    {
        _customerProfilesTableClient = new TableClient(connectionString, "CustomerProfiles");
        _productsTableClient = new TableClient(connectionString, "Products");
        _ordersTableClient = new TableClient(connectionString, "Orders");
    }

    // Customer Profiles Methods
    public async Task<List<CustomerProfiles>> GetAllCustomerProfilesAsync()
    {
        var customerProfiles = new List<CustomerProfiles>();

        await foreach (var profile in _customerProfilesTableClient.QueryAsync<CustomerProfiles>())
        {
            customerProfiles.Add(profile);
        }

        return customerProfiles;
    }

    public async Task AddCustomerProfileAsync(CustomerProfiles profile)
    {
        if (string.IsNullOrEmpty(profile.PartitionKey) || string.IsNullOrEmpty(profile.RowKey))
        {
            throw new ArgumentException("PartitionKey and RowKey must be set.");
        }

        try
        {
            await _customerProfilesTableClient.AddEntityAsync(profile);
        }
        catch (RequestFailedException ex)
        {
            throw new InvalidOperationException("Error adding entity to CustomerProfiles Table Storage", ex);
        }
    }

    public async Task DeleteCustomerProfileAsync(string partitionKey, string rowKey)
    {
        await _customerProfilesTableClient.DeleteEntityAsync(partitionKey, rowKey);
    }

    public async Task<CustomerProfiles?> GetCustomerProfileAsync(string partitionKey, string rowKey)
    {
        try
        {
            var response = await _customerProfilesTableClient.GetEntityAsync<CustomerProfiles>(partitionKey, rowKey);
            return response.Value;
        }
        catch (RequestFailedException ex) when (ex.Status == 404)
        {
            return null;
        }
    }

    // Products Methods
    public async Task<List<Product>> GetAllProductsAsync()
    {
        var products = new List<Product>();

        await foreach (var product in _productsTableClient.QueryAsync<Product>())
        {
            products.Add(product);
        }

        return products;
    }

    public async Task AddProductAsync(Product product)
    {
        if (string.IsNullOrEmpty(product.PartitionKey) || string.IsNullOrEmpty(product.RowKey))
        {
            throw new ArgumentException("PartitionKey and RowKey must be set.");
        }

        try
        {
            await _productsTableClient.AddEntityAsync(product);
        }
        catch (RequestFailedException ex)
        {
            throw new InvalidOperationException("Error adding entity to Products Table Storage", ex);
        }
    }

    public async Task DeleteProductAsync(string partitionKey, string rowKey)
    {
        await _productsTableClient.DeleteEntityAsync(partitionKey, rowKey);
    }

    public async Task<Product?> GetProductAsync(string partitionKey, string rowKey)
    {
        try
        {
            var response = await _productsTableClient.GetEntityAsync<Product>(partitionKey, rowKey);
            return response.Value;
        }
        catch (RequestFailedException ex) when (ex.Status == 404)
        {
            return null;
        }
    }

    // Orders Methods
    public async Task<List<Order>> GetAllOrdersAsync()
    {
        var orders = new List<Order>();

        await foreach (var order in _ordersTableClient.QueryAsync<Order>())
        {
            orders.Add(order);
        }

        return orders;
    }

    public async Task AddOrderAsync(Order order)
    {
        if (string.IsNullOrEmpty(order.PartitionKey) || string.IsNullOrEmpty(order.RowKey))
        {
            throw new ArgumentException("PartitionKey and RowKey must be set.");
        }

        try
        {
            await _ordersTableClient.AddEntityAsync(order);
        }
        catch (RequestFailedException ex)
        {
            throw new InvalidOperationException("Error adding entity to Orders Table Storage", ex);
        }
    }

    public async Task DeleteOrderAsync(string partitionKey, string rowKey)
    {
        await _ordersTableClient.DeleteEntityAsync(partitionKey, rowKey);
    }

    public async Task<Order?> GetOrderAsync(string partitionKey, string rowKey)
    {
        try
        {
            var response = await _ordersTableClient.GetEntityAsync<Order>(partitionKey, rowKey);
            return response.Value;
        }
        catch (RequestFailedException ex) when (ex.Status == 404)
        {
            return null;
        }
    }
}
