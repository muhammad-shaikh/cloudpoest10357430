﻿using Azure.Storage.Queues;
using System.Threading.Tasks;

public class QueueService
{
    private readonly QueueClient _queueClient;

    public QueueService(string connectionString, string v)
    {
        // Initialize the QueueClient with the connection string and queue name 'orderqueue'
        _queueClient = new QueueClient(connectionString, "orderqueue");
    }

    public async Task SendMessageAsync(string message)
    {
        try
        {
            await _queueClient.SendMessageAsync(message);
            Console.WriteLine($"Message sent to queue 'orderqueue': {message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error sending message: {ex.Message}");
            throw;
        }
    }
}
