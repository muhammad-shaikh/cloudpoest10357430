﻿using Cloud_Storage.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;
using Cloud_Storage.Services;
using Microsoft.AspNetCore.Mvc.Rendering;

public class OrdersController : Controller
{
    private readonly TableStorageService _tableStorageService;
    private readonly QueueService _queueService;

    public OrdersController(TableStorageService tableStorageService, QueueService queueService)
    {
        _tableStorageService = tableStorageService;
        _queueService = queueService;
    }

    // Action to display all orders
    public async Task<IActionResult> Index()
    {
        var orders = await _tableStorageService.GetAllOrdersAsync();
        return View(orders);
    }

    // Action to display the form to register a new order
    public async Task<IActionResult> Register()
    {
        var customers = await _tableStorageService.GetAllCustomerProfilesAsync();
        var products = await _tableStorageService.GetAllProductsAsync();

        // Check if there are any customers and products available
        if (customers == null || customers.Count == 0)
        {
            ModelState.AddModelError("", "No customers found. Please add customers first.");
            return View(); // You might consider redirecting to an appropriate action
        }

        if (products == null || products.Count == 0)
        {
            ModelState.AddModelError("", "No products found. Please add products first.");
            return View(); // You might consider redirecting to an appropriate action
        }

        // Populate the dropdown lists
        ViewData["CustomerProfiles"] = new SelectList(customers, "RowKey", "Customer_Name");
        ViewData["Products"] = new SelectList(products, "RowKey", "Product_Name");

        return View();
    }

    // Action to handle the form submission and register the order
    [HttpPost]
    public async Task<IActionResult> Register(Order order)
    {
        if (ModelState.IsValid)
        {
            // Set PartitionKey, RowKey and OrderDate before saving
            order.OrderDate = DateTime.SpecifyKind(order.OrderDate, DateTimeKind.Utc);
            order.PartitionKey = "OrdersPartition";
            order.RowKey = Guid.NewGuid().ToString();
            await _tableStorageService.AddOrderAsync(order);

            // Send a message to the queue
            string message = $"New order by Customer {order.CustomerID} for Product {order.ProductID} on {order.OrderDate} at {order.ShippingAddress}";
            await _queueService.SendMessageAsync(message);

            return RedirectToAction("Index");
        }

        // If validation fails, reload customers and products lists
        var customers = await _tableStorageService.GetAllCustomerProfilesAsync();
        var products = await _tableStorageService.GetAllProductsAsync();
        ViewData["CustomerProfiles"] = new SelectList(customers, "RowKey", "Customer_Name");
        ViewData["Products"] = new SelectList(products, "RowKey", "Product_Name");

        return View(order);
    }
}
